# Just Dance Unity2UbiArt

A simple script for converting Unity Just Dance tape's to UbiArt Just Dance tape's for making them playable in older Just Dance games (2016-2022).


## Credits

 - [Rama](https://github.com/rama0dev)
 - [Worte](https://github.com/wortestudios)

## Options

 - mapPackage (Unity .bundle files)
 - Raw input (check [input](/input/MapName) for example)

### - Please credit us in your work.

![WatchOutForThis](http://media.discordapp.net/attachments/890634122299605044/1045046253714690159/Unity2UbiArt.png)
